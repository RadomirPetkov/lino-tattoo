# Virilica

Version 0.2
By Веско Радић <radic.vesko@gmail.com>

About
-----

Yet another OFL font generally intended for comics. It is a hobby project, so I accept responsibility for all possible mistakes in advance.

![virilica_example](https://github.com/VeskoRadic/virilica-font/blob/main/lorem_ipsum.png)

Licence
-------

Virilica is released under the [OFL](https://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL) licence.
